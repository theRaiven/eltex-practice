#!/bin/bash
WORK_DIR="$(dirname "$0")"
cd "$WORK_DIR" || exit 1
CONF_FILE="$WORK_DIR/observer.conf"
LOG_FILE="$WORK_DIR/observer.log"

# проверка наличя файла конфигурайии 
if [[ ! -f "$CONF_FILE" ]]; then
   echo "$(date '+%Y-%m-%d %H:%M:%S') observer.conf не найден" >> "$LOG_FILE"

   exit 1
fi

# читаем список задач
while IFS= read -r TASK; do
   [[ -z "$TASK" ]] && continue
   FOUND=0

   # поиск задач среди процессов через /proc
   for PROC in /proc/[0-9]*;do
       if [[ -r "$PROC/cmdline" ]]; then
          CMD=$(tr '\0' ' ' < "$PROC/cmdline")
          if [[ "$CMD" == *"$TASK"* ]]; then
             FOUND=1
             break;
fi
fi
done

   # если задачи не запущена, то nohup
    if [[ "$FOUND" -eq 0 ]]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') Запуск $TASK" >> "$LOG_FILE"
        nohup "$WORK_DIR/$TASK" >> "$LOG_FILE" 2>&1 &
    else
       echo "$(date '+%Y-%m-%d %H:%M:%S') $TASK уже запущен" >> "$LOG_FILE"
    fi
done < "$CONF_FILE"
