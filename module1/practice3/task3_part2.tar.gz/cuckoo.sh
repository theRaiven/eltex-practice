#!/bin/bash
PIPE=""
LOG_FILE="$(dirname "$0")/cuckoo.log"

# путь к каналу из --pishitesuda=
for arg in "$@"; do
    case "$arg" in
        --pishitesuda=*)
            PIPE="${arg#--pishitesuda=}"
            ;;
    esac
done

# проверка параметров
if [[ -z "$PIPE" || "$PIPE" != /* ]]; then
    echo "Error: Specify the absolute path --pishitesuda=/path/to/canal"
    exit 1
fi

# если старый канал остался - удаляем его
if [[ -p "$PIPE" ]]; then
    rm -f "$PIPE"
elif [[ -e "$PIPE" ]]; then
    echo "Error: $PIPE already exists and is not a named pipe."
    exit 1
fi

# создаем канал
mkfifo "$PIPE"
echo "$(date '+%Y-%m-%d %H:%M:%S') Startup!" >> "$LOG_FILE"
# обработчик SIGTERM
shutdown()
{

    echo "$(date '+%Y-%m-%d %H:%M:%S') Shutdown!" >> "$LOG_FILE"
    rm -f "$PIPE"
    exit 0
}
trap shutdown SIGTERM

# считываем запросы из канала
while true; do
    if IFS= read -r MESSAGE < "$PIPE"; then
       if [[ "$MESSAGE" =~ ^(.+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            NAME="${BASH_REMATCH[1]}"
            PID="${BASH_REMATCH[2]}"
            # случайное число от 2 до 10
            N=$((RANDOM % 9 + 2))
            echo "$(date '+%Y-%m-%d %H:%M:%S') ${NAME}[${PID}] ${N}" >> "$LOG_FILE"
            echo "$N" > "$PIPE"
fi
fi
done
