#!/bin/bash

SCRIPT_NAME="$(basename "$0")"
PIPE="/tmp/cuckoo_pipe"

# шаблон не выполняет работы
if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

# запрос pid из procfs
PID=$(awk '/^Pid:/ {print $2}' "/proc/$$/status")
LOG_FILE="$PWD/report_${SCRIPT_NAME}.log"

echo "$(date '+%Y-%m-%d %H:%M:%S') [${PID}] Скрипт запущен" >> "$LOG_FILE"

# проверка наличия канада 
if [[ ! -p "$PIPE" ]]; then
   echo "Ошибка: канал $PIPE не найден"
   exit 1
fi

# отправляем запрос в cuckoo.sh
printf "%s[%s]: how much time do I have?\n" "$SCRIPT_NAME" "$PID" > "$PIPE"
read -r N < "$PIPE"

sleep "$N"
echo "$(date '+%Y-%m-%d %H:%M:%S') [${PID}] Скрипт завершился, работал ${N} секунд." >> "$LOG_FILE"
